<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Api extends REST_Controller {

    public $data = "";
    function __construct() {
        parent::__construct();
        ini_set('display_errors', 1);
        $this->load->model('User_model');
        $check = $this->User_model->checkAuthToken();
        if($check == false)
        {
            $response       = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(101),'data'=>array());
            $this->response($response);
        }
    }
    
    // Client detail api
    public function clientdetail_post()
    {
        $client_id = $this->post('client_id');
        $data = $this->db->get_where('client',array('id'=>$client_id))->result();
        if(!isset($data[0]))
        {
            $response       = array('status'=>FAIL,'message'=>'Clieent Not Exist','data'=>$data);
        }else{
            $data = $data[0];   
            $data->encrypt_id = encoding($data->id);
            if($data->document != null)
            {
                $data->document = base_url('uploads/client/').$data->document;
            }
            if($data->profile_photo != null)
            {
                $data->profile_photo = base_url('uploads/client/').$data->profile_photo;
            }
            $response       = array('status'=>SUCCESS,'message'=>'Client Detail Get Succesfully','data'=>$data);
        }
        $this->response($response);
    }
    
    public function getallproject_post()
    {
        $user_id = $this->post('user_id');
        $role = $this->post('role');
        $sql = $this->db->select('project.*, invite_people.is_removed')
         ->from('project')
         ->join('invite_people', 'project.id = invite_people.project_id')
         ->where('invite_people.user_id',$user_id)
         ->where('invite_people.role',$role);
        if(isset($_POST['name']) && $_POST['name'] != "")
        {
            $name = $_POST['name'];
            $sql = $sql->like('name', $name);
        }
        if(isset($_POST['status']) && $_POST['status'] != -1 && $_POST['status'] != "")
        {
            $status = $_POST['status'];
            $sql = $sql->like('status', $status);
        }
        $this->db->distinct();
        $data = $this->db->get()->result();
        $response       = array('status'=>SUCCESS,'data'=>$data,'message'=>'Project List Get Succesfully');
        $this->response($response);
    }
    
    public function projectdetail_post()
    {
        $project_id = $this->post('project_id');
        $data = $this->db->get_where('project',array('id'=>$project_id))->result();
        if(!isset($data[0]))
        {     
            $response       = array('status'=>FAIL,'data'=>$data,'message'=>'Project Not Exist');
        }else{
            $data = $data[0];   
            $client_id = $data->client;
            $clientData = $this->db->get_where('client',array('id'=>$client_id))->result();
            if(isset($clientData[0]))
                $data->client_data = $clientData[0];
            else
                $data->client_data = NULL;
            $data->encrypt_id = encoding($data->id);
            if($data->document != null)
            {
                $data->document = base_url('uploads/project/').$data->document;
            }
            $response       = array('status'=>SUCCESS,'data'=>$data,'message'=>'Project Detail Get Succesfully');
        }
        $this->response($response);
    }
    
    public function projecttasklist_post()
    {
        $projectid = $_POST['project_id'];
        
        $this->db->where('project_id',$projectid);
        $this->db->where('created_by',0);
        $this->db->order_by('taskId','desc');
        
        if(isset($_POST['status']) && $_POST['status'] != -1 && $_POST['status'] != "")
        {
            $this->db->where('task_status', $_POST['status']);
        }
        if(isset($_POST['name']) && $_POST['name'] != "")
        {
            $this->db->like('name', $_POST['name']);
        }
        $task_list = $this->db->get('tasks')->result();
        foreach($task_list as $value)
        {
            $value->encrypt_id = encoding($value->taskId);
            $taskId = $value->taskId;
            $task_meta = $this->common_model->getAll('task_meta',array('taskId'=>$taskId),'sorting_order','desc');  
            $value->meta_data = $task_meta;
        }
        echo json_encode(array('success'=>true,'task_list'=>$task_list));
    }
    
    public function projecttasklistdetail_post()
    {
        $id = $this->post('task_id');      
        $data = $this->db->get_where('tasks',array('taskId'=>$id))->result();
        foreach ($data as $key => $value) {
            $this->db->order_by('sorting_order','asc');
            $meta_data = $this->db->get_where('task_meta',array('taskId'=>$id))->result();
            $value->id = encoding($value->taskId);
            foreach ($meta_data as $key2 => $value2) {
                $value2->newId = encoding($value2->taskmetaId);
                if($value2->file != "")
                {
                    if($value2->fileType=='IMAGE')
                    {
                        $value2->file = base_url('uploads/task_image/').$value2->file;
                    }else if($value2->fileType=='VIDEO'){
                        $value2->file = base_url('uploads/task_video/').$value2->file;    
                    }
                }
            }
            $value->meta_data = $meta_data;
            
            
            
            //
            $involved_people = array();
            $noninvolved_people = array();
            $invite_people_data = $this->db->get_where('invite_people',array('taskId'=>$id))->result();
            foreach($invite_people_data as $value)
            {
                if($value->role == 'leadcontractor' || $value->role == 'subcontractor')
                {
                    $user_data = $this->db->get_where('contractor',array('id'=>$value->user_id))->result();
                    $value->user_name = $user_data[0]->owner_first_name.' '.$user_data[0]->owner_last_name;
                    $value->user_email = $user_data[0]->email;
                }else if($value->role == 'crew'){
                    $user_data = $this->db->get_where('crew_member',array('id'=>$value->user_id))->result();
                    $value->user_name = $user_data[0]->name;
                    $value->user_email = $user_data[0]->email;
                }
                if($value->is_removed == 0)
                {
                    array_push($involved_people,$value);
                }else{
                    array_push($noninvolved_people,$value);
                }
            }
            $value->involved_people = $involved_people;
            $value->noninvolved_people = $noninvolved_people;
            //
        }
        $task_detail              = $data[0];
        $response = array('success'=>true,'message'=>'Task Details retrived successfully.','data'=>$task_detail);
        echo json_encode($response);
    }
    
    // change password
    public function changepassword_post()
    {
        $user_id = $this->post('user_id');
        $old_pass = $this->post('old_pass');
        $new_pass = $this->post('new_pass');
        $confirm_pass = $this->post('confirm_pass');
        $role = $this->post('role');
        if($role == 'crew')
        {
            $role = 'crew_member';
        }else if($role = 'leadcontractor' || $role = 'subcontractor')
        {
            $role = 'contractor';
        }
        $where          = array('id' => $user_id);
        $user_data          = $this->common_model->getsingle($role, $where,'password');
        
        if(password_verify($old_pass, $user_data['password'])){
            $set = array('password'=> password_hash($this->input->post('npassword') , PASSWORD_DEFAULT));
            $update = $this->common_model->updateFields($role, $set, $where);
            if($update){
                $res = array();
                if($update){
                    $response = array('status' =>SUCCESS, 'message' => 'Successfully Updated','data'=>array());
                }else{
                    $response = array('status' =>FAIL, 'message' => 'Failed! Please try again','data'=>array());
                }
            }
        }else{
            $response = array('status' =>FAIL, 'message' => 'Your Current Password is Wrong !','data'=>array());
        }
        
        $this->response($response);
    }
    
    // Add Task Stesp
    public function addTaskStep_post(){
        $this->form_validation->set_rules('id', 'id', 'trim|required');
        $this->form_validation->set_rules('taskstepId', 'task step', 'trim|required');
     
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => strip_tags(validation_errors()));    
        }else{
            $taskId                  = decoding($this->post('id'));
            $where                      = array('taskId'=>$taskId);
            $isExist                    = $this->common_model->is_data_exists('tasks',$where);

            if($isExist){
            $taskstep = $this->post('taskstepId');
            switch ($taskstep) {
                case 'image':
                      $this->load->model('Image_model');
                    $imagefileId              = $this->post('imagefileId_1');
                    if (!empty($_FILES['fileImage_1']['name'])) {
                    $imageF = $this->Image_model->updateDocument('fileImage_1','task_image');
                 
                    if(array_key_exists("image_name",$imageF)):
                        
                        $file             =  $imageF['image_name'];

                        $data_val['fileType']              = 'IMAGE';
                        $data_val['file']              = $file;

                        $isImage                          = $this->common_model->is_data_exists('task_meta',array('taskmetaId'=>$imagefileId));
                        if($isImage){
                            $this->common_model->updateFields('task_meta',$data_val,array('taskmetaId'=>$imagefileId));
                            $status = SUCCESS;
                            $msg    = "Layer record updated successfully.";
                        }else{
                            $data_val['taskId']     = $taskId;
                            $this->common_model->insertData('task_meta',$data_val);
                            $status = SUCCESS;
                            $msg    = "Layer record added successfully.";
                        }

                    endif;

                    } 
                    break;
                case 'video':
                      $this->load->model('Image_model');
                    $videofileId              = $this->post('videofileId_1');
                    if (!empty($_FILES['videofile_1']['name'])) {
                    $videoF=$this->Image_model->updateDocument('videofile_1','task_video');
                    //check for image name if present
                        if(array_key_exists("image_name",$videoF)):
                        $file            =  $videoF['image_name'];
                        $data_val['fileType']              = 'VIDEO';
                        $data_val['file']              = $file;

                        $isVideo                          = $this->common_model->is_data_exists('task_meta',array('taskmetaId'=>$videofileId));
                        if($isVideo){
                            $this->common_model->updateFields('task_meta',$data_val,array('taskmetaId'=>$videofileId));
                            $status = SUCCESS;
                            $msg    = "Layer record updated successfully.";
                        }else{
                            $data_val['taskId']     = $taskId;
                            $this->common_model->insertData('task_meta',$data_val);
                            $status = SUCCESS;
                            $msg    = "Layer record added successfully.";
                        }

                        endif;
                    }
                    break;
                
                default:
                    $textfile                = $this->post('textfile_1');
                    $textfileId              = $this->post('textfileId_1');
                    $data_val['description']       = $textfile;
                    $data_val['fileType']              = 'TEXT';
                    
                    $isText                          = $this->common_model->is_data_exists('task_meta',array('taskmetaId'=>$textfileId));
                    if($isText){
                        $this->common_model->updateFields('task_meta',$data_val,array('taskmetaId'=>$textfileId));
                        $status = SUCCESS;
                        $msg    = "Layer record updated successfully.";
                    }else{
                        $data_val['taskId']     = $taskId;
                        $this->common_model->insertData('task_meta',$data_val);
                         $status = SUCCESS;
                        $msg    = "Layer record added successfully.";
                    }
                    break;
            }
             $response              = array('status'=>$status,'message'=>$msg);

            }else{
                $response              = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118));
            }        
        }
        $this->response($response);
    }//end function 
    
    // Create New Task
    public function addnew_post(){
        
        $data_val['name']         = $this->post('name');
        $data_val['description']        = $this->post('description');
        $data_val['project_id'] = $this->post('project_id');
        $data_val['company_id'] = $this->post('company_id');
        $data_val['created_by'] = 0;
        $result   = $this->common_model->insertData('tasks',$data_val);
        $taskId   = $result;
        $company_id = $this->post('company_id');
        if(isset($_POST['preopulated_ids']) && $_POST['preopulated_ids'] != 0)
        {
            $importedid = $this->post('preopulated_ids');
            $ALlData = $this->db->get_where('task_meta',array('taskId'=>$importedid))->result();
            foreach($ALlData as $ALL){
                $InsertArray = array(
                    'taskId' => $taskId,
                    'fileType' => $ALL->fileType,
                    'file' => $ALL->file,
                    'description' => $ALL->description,
                    'sorting_order' => $ALL->sorting_order
                );
                $this->db->insert('task_meta',$InsertArray);
            }
                
        }else{
            $textData = $this->input->post('textfile_1');
            $textData = json_decode($textData);
            foreach($textData as $key=>$value)
            {
              $array = array(
                  'fileType' => 'TEXT',
                  'description' => $value,
                  'taskId' => $taskId
              );
              $result = $this->common_model->insertData('task_meta',$array);
            }
                $textData = $this->input->post('inserted_steps');
            $textData = json_decode($textData);
            foreach($textData as $key=>$value)
            {
                $this->db->where('taskmetaId',$value);
                    $result = $this->db->update('task_meta',array('taskId'=>$taskId));
            }
        }
        if(isset($_POST['contractorIds']))
        {
            $contractorIds = json_decode($_POST['contractorIds']);
            foreach($contractorIds as $contractor)
            {
                $type = 'leadcontractor';
                $contractorData = $this->db->get_where('contractor',array('id'=>$contractor))->result();
                if(isset($contractorData[0]))
                {
                    $contractorData = $contractorData[0];
                    $invitenewpeoplename = $contractorData->owner_first_name;
                    $invitenewpeopleemail = $contractorData->email;
                    $last_id = $contractorData->id;
                    $this->inviteNewPeople($invitenewpeoplename,$invitenewpeopleemail,$is_for='task',$taskId,$type,$company_id,$last_id);    
                }
            }
        }
        if(isset($_POST['crewIds']))
        {
            $crewIds = json_decode($_POST['crewIds']);
            foreach($crewIds as $crew)
            {
                $type = 'crew';
                $crewData = $this->db->get_where('crew_member',array('id'=>$crew))->result();
                if(isset($crewData[0])){
                    $crewData = $crewData[0];
                    $invitenewpeoplename = $crewData->name;
                    $invitenewpeopleemail = $crewData->email;
                    $last_id = $crewData->id;
                    $this->inviteNewPeople($invitenewpeoplename,$invitenewpeopleemail,$is_for='task',$taskId,$type,$company_id,$last_id);   
                }
            }
        }
        $msg = 'Task Added Successfully';
        if($result){
            $response = array('status'=>SUCCESS,'data'=>$_POST,'message'=>$msg,'url'=>base_url().'task-detail/'.encoding($taskId));
        }else{
            $response              = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118));
        }
        $this->response($response);
    }
    
    function ChangeTaskStatus_post()
    {
        $taskId         = $_POST['taskId'];
        $this->db->where('taskId',$taskId);
        $tasks_data = $this->db->get('tasks')->result();
        $tasks_data = $tasks_data[0];
        if($tasks_data->task_status == 0)
        {
            $task_status = "1";
        }else{
            $task_status = "0";
        }
        $set        = array('task_status'=> $task_status); 
        $where          = array('taskId' => $taskId);
        $update     = $this->common_model->updateFields('tasks', $set, $where);
        
        $data = array('status'=>'success','message'=>'Task Status Changes Succesfully','data'=>array());
        echo json_encode($data);
    }
    
    // add Crew Member
    function addcrewmember_post(){
        $this->load->model('Crew_model');
        $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[2]');
            if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => strip_tags(validation_errors()),'data'=>array());
            $this->response($response);
        }else{
            $email                          =  $this->post('email');
            $name                       =  $this->post('name');
            $userData['name']           =   $name;
            $userData['email']              =   $email;
            $userData['phone_number']      =   $this->post('phone_number');
            $userData['address']      =   $this->post('address');
            $userData['company_id']      =   0;
            $role                     =  $this->post('role');
            // profile pic upload
            $config['upload_path']= "./uploads/crew/";
            $config['allowed_types']='*';
            $config['encrypt_name'] = FALSE;
            $this->load->library('upload',$config);
            $licence = "";
            $insurence_certificate = "";
            if(isset($_FILES['licence']))
            {
                $licence = $_FILES['licence']['name'];
            }
            if(isset($_FILES['insurence_certificate']))
            {
                $insurence_certificate = $_FILES['insurence_certificate']['name'];   
            }
            if($licence != "")
            {
                if($this->upload->do_upload('licence'))
                {
                    $data = array('upload_data' => $this->upload->data());
                    $licence= $data['upload_data']['file_name'];
                }else{
                    $error = $this->upload->display_errors(); 
                    $error = 'It will accept only doc, docx, pdf, ppt, jpeg, jpg, png, bmp format files.';
                    $response              = array('status'=>FAIL,'message'=>$error);
                    $this->response($response);
                    die;
                }
            }
            if($insurence_certificate != "")
            {
                if($this->upload->do_upload('insurence_certificate'))
                {
                    $data = array('upload_data' => $this->upload->data());
                    $insurence_certificate= $data['upload_data']['file_name'];
                }else{
                    $error = $this->upload->display_errors(); 
                    $error = 'It will accept only doc, docx, pdf, ppt, jpeg, jpg, png, bmp format files.';
                    $response              = array('status'=>FAIL,'message'=>$error);
                    $this->response($response);
                    die;
                }
            }
            $userData['licence']               =   $licence;
            $userData['insurence_certificate'] =   $insurence_certificate;
            $result = $this->Crew_model->registration($userData);
            if(is_array($result)){
                switch ($result['regType']){
                    case "NR": // Normal registration
                        $response = array('status'=>SUCCESS,'message'=>'Crew Member Added Successfully', 'data'=>array());
                        // send crew invitaion
                        $array = array(
                            'sender_id' => $this->post('user_id'),
                            'sender_type' => $role,
                            'receiver_id' => $this->db->insert_id(),
                            'reciever_type' => 'crew',
                            'is_for' => 'account'
                        );
                        $this->db->insert('invite',$array);
                        $id = $this->db->insert_id();
                        $link = base_url().'invitation/'.encoding($id);
                        $data1['full_name']  = $result['returnData'][0]->name;
                        $data1['url']        = $link;
                        $message            = $this->load->view('emails/member_invite',$data1,TRUE);
                        $subject = 'Leadsafe - Account Invitation link';
                        $to = $result['returnData'][0]->email;
                        $this->common_model->sendMemberMail($to,$link,$message,$subject);
                        // end
                    break;
                    case "AE": // User already registered
                        $num_rows = $this->db->get_where('contractor_member_relationship',array('contractor_id'=>$this->post('user_id'),'member_id'=>$result['existId'],'type'=>'crew'))->num_rows();
                        if($num_rows>0){
                            $response = array('status'=>FAIL,'message'=>'Crew Member Already Registered','users'=>array());
                        }else{
                            $response = array('status'=>SUCCESS,'message'=>'Crew Member Invited Successfully','data'=>array());
                            // send crew invitaion
                            $reciever_data = $this->db->get_where('crew_member',array('id'=>$result['existId']))->result();
                            $reciever_data = $reciever_data[0];
                            $full_name= $reciever_data->name;
                            $array = array(
                                'sender_id' => $this->post('user_id'),
                                'sender_type' => $role,
                                'receiver_id' => $result['existId'],
                                'reciever_type' => 'crew',
                                'is_for' => 'account'
                            );
                            $this->db->insert('invite',$array);
                            $id = $this->db->insert_id();
                            $link = base_url().'invitation/'.encoding($id);
                            $data1['full_name']  = $full_name;
                            $data1['url']        = $link;
                            $message            = $this->load->view('emails/member_invite',$data1,TRUE);
                            $subject = 'Leadsafe - Account Invitation link';
                            $to = $email;
                            $this->common_model->sendMemberMail($to,$link,$message,$subject);
                            // end
                        }
                    break;
                    default:
                        $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(121),'data'=>array());
                }
            }else{
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118),'data'=>array());
            }   
            $this->response($response);
        }
    }
    
    // add Contractor 
    function addsubcontractor_post(){
        $this->load->model('Contractor_model');
        $this->form_validation->set_rules('phone_number', 'Phone Number', 'trim|required|min_length[10]|max_length[20]');
        
        $this->form_validation->set_rules('company_name', 'Name', 'trim|required|min_length[2]');
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => strip_tags(validation_errors()),'data'=>array());
            $this->response($response);
        }else{
            $email                          =  $this->post('email');
            $company_name                       =  $this->post('company_name');
            $userData['company_name']           =   $company_name;
            $userData['email']              =   $email;
            $userData['phone_number']      =   $this->post('phone_number');
            $userData['address']      =   $this->post('address');
            $userData['company_id']      =   0;
            $userData['owner_first_name']      =   $this->post('owner_first_name');
            $userData['owner_last_name']      =   $this->post('owner_last_name');
            $userData['is_role']      =   1;
            $userData['state']      =   $this->post('state');
            $userData['city']      =   $this->post('city');
            
            $role = $this->post('role');
            
            // profile pic upload
            $config['upload_path']= "./uploads/contractor/";
            $config['allowed_types']='*';
            $config['encrypt_name'] = FALSE;
            $this->load->library('upload',$config);

            if($this->upload->do_upload('licence'))
            {
                $data = array('upload_data' => $this->upload->data());
                $licence= $data['upload_data']['file_name'];
            }
            if($this->upload->do_upload('insurence_certificate'))
            {
                $data = array('upload_data' => $this->upload->data());
                $insurence_certificate= $data['upload_data']['file_name'];
            }

            $userData['licence']               =   $licence;
            $userData['insurence_certificate'] =   $insurence_certificate;

            $result = $this->Contractor_model->registration($userData);
            if(is_array($result)){
                switch ($result['regType']){
                    case "NR": // Normal registration
                        $response = array('status'=>SUCCESS,'message'=>'Contractor Invitation Send Successfully', 'data'=>array());
                        // send contractor invitaion
                        $array = array(
                            'sender_id' => $this->post('user_id'),
                            'sender_type' => $role,
                            'receiver_id' => $this->db->insert_id(),
                            'reciever_type' => 'subcontractor',
                            'is_for' => 'account'
                        );
                        $this->db->insert('invite',$array);
                        $id = $this->db->insert_id();
                        $link = base_url().'invitation/'.encoding($id);
                        $data1['full_name']  = $result['returnData'][0]->owner_first_name;
                        $data1['url']        = $link;
                        $message            = $this->load->view('emails/member_invite',$data1,TRUE);
                        $subject = 'Leadsafe - Account Invitation link';
                        $to = $result['returnData'][0]->email;
                        $this->common_model->sendMemberMail($to,$link,$message,$subject);
                        // end
                    break;
                    case "AE": // User already registered
                        $num_rows = $this->db->get_where('company_member_relations',array('company_id'=>$this->post('company_id'),'member_id'=>$result['existId'],'type'=>'leadcontractor'))->num_rows();
                        if($num_rows>0){
                            $response = array('status'=>FAIL,'message'=>'Contractor Already Registered With Your Company','data'=>array());
                        }else{
                            // send contractor invitaion
                            $reciever_data = $this->db->get_where('contractor',array('id'=>$result['existId']))->result();
                            $reciever_data = $reciever_data[0];
                            $full_name= $reciever_data->owner_first_name;
                            $array = array(
                                'sender_id' => $this->post('user_id'),
                                'sender_type' => $role,
                                'receiver_id' => $result['existId'],
                                'reciever_type' => 'subcontractor',
                                'is_for' => 'account'
                            );
                            $this->db->insert('invite',$array);
                            $id = $this->db->insert_id();
                            $link = base_url().'invitation/'.encoding($id);
                            $data1['full_name']  = $full_name;
                            $data1['url']        = $link;
                            $message            = $this->load->view('emails/member_invite',$data1,TRUE);
                            $subject = 'Leadsafe - Account Invitation link';
                            $to = $email;
                            $this->common_model->sendMemberMail($to,$link,$message,$subject);
                            $response = array('status'=>SUCCESS,'message'=>'Contractor Invitation Send Successfully', 'data'=>array());
                            //end
                        }
                    break;
                    default:
                        $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(121),'data'=>array());
                }
            }else{
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118),'data'=>array());
            }   
            $this->response($response);
        }
    }
    
    // invite For Project
    function inviteExistingPeopleForProject_post()
    {
        $invitenewpeoplename  = "";
        $invitenewpeopleemail  = "";
        $reciever_type = $_POST['reciever_type'];
        $receiver_id = $_POST['receiver_id'];
        
        if($reciever_type == "leadcontractor" || $reciever_type == "subcontractor")
        {
            $reciever_data = $this->db->get_where('contractor',array('id'=>$receiver_id))->result();
            $reciever_data = $reciever_data[0];
            $invitenewpeoplename= $reciever_data->owner_first_name;
            $invitenewpeopleemail= $reciever_data->email;
        }else if($reciever_type == "crew")
        {
            $reciever_data = $this->db->get_where('crew_member',array('id'=>$receiver_id))->result();
            $reciever_data = $reciever_data[0];
            $invitenewpeoplename= $reciever_data->name;
            $invitenewpeopleemail= $reciever_data->email;
        }
        $is_for = 'project';
        $project_id = $_POST['project_id'];
        $user_id = $_POST['user_id'];
        $last_id = $receiver_id;
        $num_rows = $this->db->get_where('invite_people',array('project_id'=>$project_id,'user_id'=>$last_id,'role'=>$_POST['role']))->num_rows();
        if($num_rows>0){
            $message = 'You are already Added in This Project.';
            $response = array('status'=>FAIL,'message'=>$message,'data'=>array());
        }else{    
            // send client invitaion
            $array = array(
                'sender_id' => $user_id,
                'sender_type' => $_POST['role'],
                'receiver_id' => $last_id,
                'reciever_type' => $reciever_type,
                'is_for' => 'project',
                'project_id'=>$project_id
            );
            $project_data = $this->db->get_where('project',array('id'=>$project_id))->result();
            $project_data = $project_data[0];
            $this->db->insert('invite',$array);
            $id = $this->db->insert_id();
            $link = base_url().'invitation/'.encoding($id);
            $data1['full_name']  = $invitenewpeoplename;
            $data1['url']        = $link;
            $data1['sender_type']  = $_POST['role'];
            $data1['is_role']  = 'project';
            $data1['title']  = $project_data->name;
            $message            = $this->load->view('emails/work_invite',$data1,TRUE);
            $subject = 'Leadsafe - Project Invitation link';
            $to = $invitenewpeopleemail;
            $this->common_model->sendMemberMail($to,$link,$message,$subject);
            $response = array('status'=>SUCCESS,'message'=>'People Invited Successfully','data'=>array());
            // end
        }
        echo json_encode($response);
    }
    
    // invite for task
    function inviteExistingPeopleForTask_post()
    {
        $reciever_type = $_POST['reciever_type'];
        $sender_type = $_POST['role'];
        $receiver_id = $_POST['receiver_id'];
        if($reciever_type == "leadcontractor" || $reciever_type == "subcontractor")
        {
            $reciever_data = $this->db->get_where('contractor',array('id'=>$receiver_id))->result();
            $reciever_data = $reciever_data[0];
            $invitenewpeoplename= $reciever_data->owner_first_name;
            $invitenewpeopleemail= $reciever_data->email;
        }else if($reciever_type == "crew")
        {
            $reciever_data = $this->db->get_where('crew_member',array('id'=>$receiver_id))->result();
            $reciever_data = $reciever_data[0];
            $invitenewpeoplename= $reciever_data->name;
            $invitenewpeopleemail= $reciever_data->email;
        }
        $is_for ='task';
        $taskId = $_POST['task_id'];
        $last_id = $receiver_id;
        $user_id = $_POST['user_id'];
        $this->inviteNewPeople($invitenewpeoplename,$invitenewpeopleemail,$is_for,$taskId,$reciever_type,$user_id,$last_id,$sender_type);
        $msg = 'People Invited Successfulyy';
        $response              = array('status'=>SUCCESS,'message'=>$msg,'data'=>array());
        $this->response($response);
    }
    
    function inviteNewPeople($invitenewpeoplename,$invitenewpeopleemail,$is_for,$taskId,$type,$user_id,$last_id,$sender_type)
    {
        $array = array(
            'sender_id' => $user_id,
            'sender_type' => $sender_type,
            'receiver_id' => $last_id,
            'reciever_type' => $type,
            'is_for' => $is_for,
            'taskId'=>$taskId
        );
        $project_data = $this->db->get_where('tasks',array('taskId'=>$taskId))->result();
        $project_data = $project_data[0];
        $this->db->insert('invite',$array);
        $id = $this->db->insert_id();
        $link = base_url().'invitation/'.encoding($id);
        $data1['full_name']  = $invitenewpeoplename;
        $data1['url']        = $link;
        $data1['sender_type']  = $sender_type;
        $data1['is_role']  = $is_for;
        $data1['title']  = $project_data->name;
        $message            = $this->load->view('emails/work_invite',$data1,TRUE);
        $subject = 'Leadsafe - Task Invitation link';
        $to = $invitenewpeopleemail;
        $this->common_model->sendMemberMail($to,$link,$message,$subject);
    }
    
    // create and invite for project
    public function inviteNewPeopleCreateandSend_post()
    {
        $is_for = 'project';
        $project_id = $_POST['project_id'];
        $reciever_type = $_POST['reciever_type'];
        $sender_type = $_POST['role'];
        $user_id = $_POST['user_id'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $last_id = 0;
        if($reciever_type == "leadcontractor" || $reciever_type == "subcontractor")
        {
            $reciever_data = $this->db->get_where('contractor',array('email'=>$email))->result();
            if(isset($reciever_data[0]))
            {
                $reciever_data = $reciever_data[0];
                $last_id = $reciever_data->id;
                $name = $reciever_data->owner_first_name;
            }else{
                $datainsert = array('owner_first_name'=>$name,'email'=>$email);
                $this->db->insert('contractor',$datainsert);
                $last_id = $this->db->insert_id();
            }
        }else if($reciever_type == "crew")
        {
            $reciever_data = $this->db->get_where('crew_member',array('email'=>$email))->result();
            if(isset($reciever_data[0]))
            {
                $reciever_data = $reciever_data[0];
                $last_id = $reciever_data->id;
                $name = $reciever_data->name;
            }else{
                $datainsert = array('name'=>$name,'email'=>$email);
                $this->db->insert('crew_member',$datainsert);
                $last_id = $this->db->insert_id();
            }
        }
        // project invitaion
        $array = array(
            'sender_id' => $user_id,
            'sender_type' => $sender_type,
            'receiver_id' => $last_id,
            'reciever_type' => $reciever_type,
            'is_for' => 'project',
            'project_id'=>$project_id
        );
        $project_data = $this->db->get_where('project',array('id'=>$project_id))->result();
        $project_data = $project_data[0];
        $this->db->insert('invite',$array);
        $id = $this->db->insert_id();
        $link = base_url().'invitation/'.encoding($id);
        $data1['full_name']  = $name;
        $data1['url']        = $link;
        $data1['sender_type']  = 'company';
        $data1['is_role']  = 'project';
        $data1['title']  = $project_data->name;
        $message            = $this->load->view('emails/work_invite',$data1,TRUE);
        $subject = 'Leadsafe - Project Invitation link';
        $to = $email;
        $this->common_model->sendMemberMail($to,$link,$message,$subject);
        $response = array('status'=>SUCCESS,'message'=>'People Invited Successfully','data'=>array());
        // end
        echo json_encode($response);
    }
    
    // people list api
    public function peopleListApi_post()
    {
        $user_id = $this->post('user_id');
        $role = $this->post('role');
        $type = $this->post('type');
        if($type=='crew')
        {
            $data = $this->db->select('contractor_member_relationship.type, crew_member.*')
                 ->from('contractor_member_relationship')
                 ->join('crew_member', 'contractor_member_relationship.member_id = crew_member.id')
                 ->where('contractor_member_relationship.contractor_id',$user_id)
                 ->where('contractor_member_relationship.type',$type)
                 ->where('contractor_member_relationship.contractor_type',$role)
                 ->order_by("id", "desc")->get()->result();  
        }else if($type=='subcontractor')
        {
            $data = $this->db->select('contractor_member_relationship.type, contractor.*')
                 ->from('contractor_member_relationship')
                 ->join('contractor', 'contractor_member_relationship.member_id = contractor.id')
                 ->where('contractor_member_relationship.contractor_id',$user_id)
                 ->where('contractor_member_relationship.type',$type)
                 ->where('contractor_member_relationship.contractor_type',$role)
                 ->order_by("id", "desc")->get()->result();  
        }
        $response       = array('status'=>SUCCESS,'data'=>$data,'message'=>'People List Get Succesfully');
        $this->response($response);
    }
    
    
  
}//End Class