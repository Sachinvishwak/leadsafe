<div id="main" role="main">
  <!-- MAIN CONTENT -->
  <div id="content" class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3">
        <div class="well padding">
          <header>Success</header>
          <div class="well padding">
            <h3 class="text-center text-success">Your Password has been Changed successfully.<i class="fa fa-check"></i></h3>
          </div>
        </div> 
      </div>
    </div>
  </div>
</div>