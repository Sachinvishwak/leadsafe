<div id="main" role="main">
  <!-- MAIN CONTENT -->
  <div id="content" class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3">
        <div class="well padding">
          <header>Change Password</header>
          <div class="well padding">
            <h4 class="text-center text-danger">This link is expired <i class="fa fa-clock-o"></i></h4>
          </div>
        </div> 
      </div>
    </div>
  </div>
</div>