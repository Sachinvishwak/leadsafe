<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends Common_Back_Controller {

    public $data = "";

    function __construct() {
        parent::__construct();
        //$this->check_admin_user_session();
      //  $this->load->model('admin_model');
      ini_set('display_errors', 1);
    }//End Function
    
    public function check_profile()
    {
        $session_u_id              = $_SESSION['company_sess']['id'];
        $uData                          = $this->db->get_where('company',array('company_id'=>$session_u_id))->result();
        $uData = $uData[0];
        if($uData->phone_number == "" || $uData->phone_number == NULL || $uData->profile_photo == "" || $uData->profile_photo == NULL   )
        {
            redirect('admin/complete_profile');
        }
        return true;
    }
    
    //complete profile
    public function complete_profile()
    {
        $session_u_id              = $_SESSION['company_sess']['id'];
        $uData                          = $this->db->get_where('company',array('company_id'=>$session_u_id))->result_array();
        $uData = $uData[0];
        $data['title'] = "Complete Profile";
        $data['userData'] = $uData;
        $this->load->login_render('share/company_profile', $data);
    }

    public function index() { 
        $data['title'] = "Login";
        $this->load->login_render('login', $data);
    }//End Function

    public function signup() {
        $data['title'] = "Sign up";
        $this->load->login_render('signup', $data);
    }//End Function

    public function logout() {
        $this->session->sess_destroy();
        $this->session->set_flashdata('success', 'Sign out successfully done! ');
        $response = array('status' => 1);
        redirect(base_url('admin/signup'));
        echo json_encode($response);
        die;
    }//End Function
    
    public function check_compnay_user_session()
    {
        if(isset($_SESSION['company_sess']))
        {
            return TRUE;
        }else{
            $this->logout();
        }
    }

    public function dashboard() {
        $this->check_profile();
        $this->check_compnay_user_session();
        $data['parent']     = "Dashboard";
        $data['title']      = '<i class="fa-fw fa fa-home"></i> Dashboard';
        $user_sess_data                 = $_SESSION['company_sess']; 
        $session_u_id                   = $user_sess_data['id']; //user ID
        $where                          = array('id'=>$session_u_id,'status'=>1);//status:0 means active 
        $uData                          = $this->db->get_where('company',array('company_id'=>$session_u_id))->result();
        $uData = $uData[0];
        $data['user']                   =  $uData;
        $this->load->view('backend_includes/company_header', $data);
        $this->load->view('dashboard', $data);
        $this->load->view('backend_includes/company_footer', $data);        
    
    
    }//End Function
    
    public function searchpeoplechat()
    {
        $searchvalue = strtoupper($_POST['value']);
        $user_sess_data                 = $_SESSION['company_sess']; 
        $session_u_id = $user_sess_data['id']; //user ID
        $peopleList = $this->db->get_where('company_member_relations',array('company_id'=>$session_u_id))->result();
        $allpeopleList = array();
        foreach($peopleList as $people)
        {
            if($people->type == 'leadcontractor')
            {
                $userData = $this->db->get_where('contractor',array('id'=>$people->member_id))->result();
                if(isset($userData[0]))
                {
                    if($searchvalue != "")
                    {
                        $userData = $userData[0];
                        $mystring = strtoupper($userData->owner_first_name.' '.$userData->owner_last_name);
                        if(strpos($mystring, $searchvalue) !== false)
                        {
                            $userData->name = $userData->owner_first_name.' '.$userData->owner_last_name;
                            $userData->reciever_type = $people->type;
                            array_push($allpeopleList,$userData);  
                        }
                    }else{
                        $userData = $userData[0];
                        $userData->name = $userData->owner_first_name.' '.$userData->owner_last_name;
                        $userData->reciever_type = $people->type;
                        array_push($allpeopleList,$userData);   
                    }
                }
            }else if($people->type == 'crew')
            {
                $userData = $this->db->get_where('crew_member',array('id'=>$people->member_id))->result();
                if(isset($userData[0]))
                {
                    if($searchvalue != "")
                    {
                        $userData = $userData[0];
                        $mystring = strtoupper($userData->name);
                        if(strpos($mystring, $searchvalue) !== false)
                        {
                            $userData->reciever_type = $people->type;
                            array_push($allpeopleList,$userData);
                        }
                    }else{
                        $userData = $userData[0];
                        $userData->reciever_type = $people->type;
                        array_push($allpeopleList,$userData);
                    }
                }
            }
        }
        
        $chatpeoplehtml = "";
        
        foreach($allpeopleList as $key=>$people)
        { 
            $clickaction = "doActive("."'".$key."'".","."'".$people->reciever_type."'".")";
            $chatpeoplehtml .= '<div  class="chat_list" id="'.$key.'" onclick="'.$clickaction.'"><div class="chat_people"><div  class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="'.$people->name.'"></div><div class="chat_ib"><h5 >'.$people->name.'<span class="chat_date">position :'.$people->reciever_type.'</span></h5></div></div></div>';  
        }
        
        
        echo json_encode($chatpeoplehtml);
    }
    
    public function chat() {
        $this->check_profile();
        $this->check_compnay_user_session();
        $data['parent']     = "Dashboard";
        $data['title']      = '<img style="max-width: 31px;"src="'.base_url().'/backend_assets/img/send-message.png" alt="Girl in a jacket"> Messages';;
        $user_sess_data                 = $_SESSION['company_sess']; 
        $session_u_id                   = $user_sess_data['id']; //user ID
        $where                          = array('id'=>$session_u_id,'status'=>1);//status:0 means active 
        $uData                          = $this->db->get_where('company',array('company_id'=>$session_u_id))->result();
        $uData = $uData[0];
        $data['user']                   =  $uData;
        $peopleList = $this->db->get_where('company_member_relations',array('company_id'=>$session_u_id))->result();
        $allpeopleList = array();
        foreach($peopleList as $people)
        {
            if($people->type == 'leadcontractor' || $people->type == 'subcontractor')
            {
                $userData = $this->db->get_where('contractor',array('id'=>$people->member_id))->result();
                if(isset($userData[0]))
                {
                    $userData = $userData[0];
                    $userData->name = $userData->owner_first_name.' '.$userData->owner_last_name;
                    $userData->reciever_type = $people->type;
                    array_push($allpeopleList,$userData);
                }
            }else if($people->type == 'crew')
            {
                $userData = $this->db->get_where('crew_member',array('id'=>$people->member_id))->result();
                if(isset($userData[0]))
                {
                    $userData = $userData[0];
                    $userData->reciever_type = $people->type;
                    array_push($allpeopleList,$userData);
                }
            }
        }
        $data['peopleList']                   =  $allpeopleList;
        $this->load->view('backend_includes/company_header', $data);
        $this->load->view('chat', $data);
        $this->load->view('backend_includes/company_footer', $data);        
    
    
    }//End Function

    //view admin profile
     public function profile(){
        $data['title']      = "Company profile";
        $where              = array('company_id'=>$_SESSION['company_sess']['id']);
        $result             = $this->common_model->getsingle('company',$where);
        $data['userData']   = $result;
        $user_sess_data                 = $_SESSION['company_sess']; 
        $session_u_id                   = $user_sess_data['id']; //user ID
        $where                          = array('id'=>$session_u_id,'status'=>1);//status:0 means active 
        $uData                          = $this->db->get_where('company',array('company_id'=>$session_u_id))->result();
        $uData = $uData[0];
        $data['user']                   =  $uData;
        $this->load->view('backend_includes/company_header', $data);
        $this->load->view('company_profile', $data);
        $this->load->view('backend_includes/company_footer', $data);
    }
  
}//End Class