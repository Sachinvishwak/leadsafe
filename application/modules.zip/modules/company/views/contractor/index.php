<section id="widget-grid" class="">
	<!-- row -->
	<div class="row">
		<!-- NEW WIDGET START -->
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget jarviswidget-color-darken" id="wid-id-0" data-widget-editbutton="false" data-widget-editbutton="false" data-widget-deletebutton="false">
				<!-- widget options:
				usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">
				data-widget-colorbutton="false"
				data-widget-editbutton="false"
				data-widget-togglebutton="false"
				data-widget-deletebutton="false"
				data-widget-fullscreenbutton="false"
				data-widget-custombutton="false"
				data-widget-collapsed="true"
				data-widget-sortable="false"
				-->
				<header>
					<span class="widget-icon"> <i class="fa fa-graduation-cap"></i> </span>
					<h2>Contractor</h2>
				</header>
				<!-- widget div-->
				<div>
					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->
					</div>
					<!-- end widget edit box -->
					<!-- widget content -->
					<div class="widget-body padding">
						<div class="table-responsive">
							<table  class="table table-striped table-bordered table-hover dataTables-example-list" width="100%" data-list-url = "company/Contractorapi/list" data-id ="" data-no-record-found = "">
								<thead>			                
									<tr>
										<th data-hide="phone">ID</th>
										<th data-hide="phone,tablet">Company Name</th>
										<!--<th data-hide="phone,tablet">Owner First Name</th>-->
										<!--<th data-hide="phone,tablet">Owner Last Name</th>-->
										<th data-hide="phone,tablet">Name</th>
										<th data-hide="phone,tablet">Email</th>
										<th data-hide="phone,tablet">Address</th>
										<th data-hide="phone,tablet">Phone Number</th>
										<!--<th data-hide="phone,tablet">Role</th>-->
										<th data-hide="phone,tablet" style="width: 70.4px;">Action</th>
									</tr>
								</thead>
								<tbody>			
								</tbody>
							</table>
						</div>
					</div>
					<!-- end widget content -->
				</div>
				<!-- end widget div -->
			</div>
			<!-- end widget -->
		</article>
		<!-- WIDGET END -->
	</div>
	<!-- end row -->
</section>
<!-- end widget grid -->