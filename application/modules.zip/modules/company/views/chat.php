<!-- end widget grid-->
  <link rel="stylesheet" href="<?php echo base_url('backend_assets/css/massagechat.css')?>"/>

<!--<input type="hidden" id="user_id" value="<?= $_SESSION['company_sess']['id']; ?>" />-->
<!--<input type="hidden" id="reciever_id" value="" />-->
<!--<input type="hidden" id="reciever_type" value="" />-->
<!--<input type="hidden" id="user_type" value="company" />-->

<style>
    .inbox_msg{
        border: 1px solid #205569;
    }
    .mesgs{
        border:none!important;
    }
</style>




<div class="container" style="width:100%;max-width:80%;">
<div class="messaging">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4><strong>Members</strong></h4>
            </div>
            <div class="srch_bar">
              <div class="stylish-input-group">
                <input  onkeyup="searchchatpeople(this.value)" value="" type="text" class="search-bar"  placeholder=" Search .. " >
                <span class="input-group-addon" style="display:none;">
                <button  type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                </span> 
                </div>
            </div>
          </div>
          <style>
          .chubbybaby { font-weight: bold; }
            </style>
          <div id="chat_people" class="inbox_chat">
            <?php
                foreach($peopleList as $key=>$people)
                {  ?>
                    <div  class="chat_list" id="<?php echo $key; ?>" onclick="doActive('<?php echo $key; ?>','<?php echo $people->reciever_type; ?>')">
                      <div class="chat_people">
                        <div  class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="<?php echo $people->name; ?>"></div>
                        <div class="chat_ib">
                          <h5 ><?php echo $people->name; ?> <span class="chat_date">position : <?php echo $people->reciever_type; ?></span></h5>
                        </div>
                      </div>
                    </div>
                <?php }
            
            ?>
          </div>
        </div>
        <div class="mesgs">
          <div class="msg_history" id="yourDivID">
                <center>
                    <img  style="max-width: 46%;" src="https://cdn.freebiesupply.com/logos/large/2x/hello-design-logo-png-transparent.png"/>
                    <div class="text-center">
                        <h4>Please Select Member To Start Conversation</h4>
                    </div>
                </center>
          </div>
          <div class="type_msg">
            <div class="input_msg_write">
              <input type="text" class="write_msg" id="message_input_box" placeholder="Type a message"/>
              <form id="message-form" class="message-form" method="post" enctype='multipart/form-data'>
                  <input id="file" type="file" name="attachment" class="fa fa-paperclip" aria-hidden="true" />
                  <input type="hidden" name="file_status" value=""/>
                  <input type="hidden" id="user_id" name="user_id" value="<?= $_SESSION['company_sess']['id']; ?>" />
                  <input type="hidden" id="reciever_id" name="reciever_id" value="" />
                  <input type="text" name="message" value="" />
                  <input type="hidden" id="reciever_type" name="reciever_type" value="" />
                  <input type="hidden" id="user_type" value="company" />
              </form>
              <button class="msg_send_btn" onclick="sendMessageToDatabase()" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
            </div>
          </div>
        </div>
      </div>
    </div></div>
    <script>
    
    $("input[name='attachment']").change(function(){
            $('#message-form').submit();
    });
    
    $('#message-form').submit(function(e){
        e.preventDefault();
        var form = $(this);
        $.ajax({
            url:"<?php echo site_url('chat/Api/sendMessageToDatabaseSingle'); ?>",
            type: "post",
            dataType: 'json',
            data: new FormData(this),
            processData: false,
            contentType: false,
            beforeSend  : function() {
                preLoadshow(true);
            }, 
            success:function(res){
                if(res.message){
                alert(res.message);
                }
                preLoadshow(false);
                getTaskDocumentByName($('#document_name').val());
                $('#file').val('');
                getsentmessagestask();
                scrolled=false;
            }
        });
    })
    
    $(document).on("keyup", "#message_input_box", function(e){
        if (e.key === 'Enter' || e.keyCode === 13){
            sendMessageToDatabase();
        }
    });
    
    function searchchatpeople(value)
    {
        //let project_id = $('#hiddenId').val();
        $.ajax({
            url:"<?php echo site_url('company/Admin/searchpeoplechat'); ?>",
            type: "post",
            dataType: 'json',
            data: {value:value},
            beforeSend  : function() {
                preLoadshow(true);
            }, 
            success:function(res){
                console.log(res);
                $("#chat_people").html(res)
                preLoadshow(false);
            }
        });
    }
    
    function startmessageget()
    {
        setInterval(function()
        { 
            getsentmessagestask();
        }, 3000);
        //getsentmessagestask();
    }
        
    function getsentmessagestask(){
            reciever_id = $('#reciever_id').val();
            reciever_type = $('#reciever_type').val();
            user_type = $('#user_type').val();
            user_id = $('#user_id').val();
            
            if(reciever_id != "")
            {
                $.ajax({
                    url:"<?php echo site_url('chat/Api/getMessageToDatabaseSingle'); ?>",
                    type: "post",
                    dataType: 'json',
                    data: {user_id:user_id,reciever_id:reciever_id,reciever_type:reciever_type,user_type:user_type},
                    success:function(res){
                        if(res.count <= 0)
                        {
                            $('.msg_history').html('<center><img style="max-width: 46%;" src="https://cdn.freebiesupply.com/logos/large/2x/hello-design-logo-png-transparent.png"/><div class="text-center"><h4>Say Hii To Start Conversation</h4></div></center>')
                        }else{
                            $('.msg_history').html(res.messages)
                        }
                        
                    }
                });
            }
            
        }
    
    function doActive(reciever_id,reciever_type)
    {
        $('.chat_list').removeClass('active_chat');
        $('#'+reciever_id).addClass('active_chat');
        $('#reciever_id').val(reciever_id);
        $('#reciever_type').val(reciever_type);
        $('.msg_history').html('<center><img style="width:20%" src="https://frilysboutique.co.uk/wp-content/plugins/woocommerce-bookings-filters//assets/image/login-load.gif"/><div class="text-center"><h4>Loading ..</h4></div></center>')
        startmessageget();
    }
    function sendMessageToDatabase()
    {
        user_id = $('#user_id').val();
        reciever_id = $('#reciever_id').val();
        $('#reciever_type').val(reciever_type);
        message = $('#message_input_box').val();
        if(message == "")
        {
             swal('You can not send blank message');
            //alert('you Can not send blank message');
        }else{
            $.ajax({
                url:"<?php echo site_url('chat/Api/sendMessageToDatabaseSingle'); ?>",
                type: "post",
                data: {message:message,user_id:user_id,reciever_id:reciever_id,reciever_type:reciever_type,user_type:"company"},
                beforeSend  : function() {
                    preLoadshow(true);
                }, 
                success:function(res){
                    $('#message_input_box').val("");
                    startmessageget();
                    preLoadshow(false);
                    scrolled=false;
                }
            });   
        }
    }
    
    
    setInterval(updateScroll,1000);
    
    var scrolled = false;
    function updateScroll(){
        if(!scrolled){
            var element = document.getElementById("yourDivID");
            element.scrollTop = element.scrollHeight;
        }
    }
    
    $("#yourDivID").on('scroll', function(){
        scrolled=true;
        console.log(scrolled);
    });
        
</script>